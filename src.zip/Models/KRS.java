
package Model;

import java.util.ArrayList;


public class KRS {
    private String noKRS;
    private ArrayList<Matakuliah> paketMatakuliah;
    
    //create
    
    public void tambahMatakuliah(Matakuliah matakuliah){
        //
    }
    
    public ArrayList<Matakuliah> showMatakuliahKRS(){
        return paketMatakuliah;
    }
    
    public void setNoKRS(String noKRS){
        //
    }
    
    public String getNoKRS(){
        return noKRS;
    }
    
}
